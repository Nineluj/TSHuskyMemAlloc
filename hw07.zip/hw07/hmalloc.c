
#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>

#include "hmalloc.h"

/*
  typedef struct hm_stats {
  long pages_mapped;
  long pages_unmapped;
  long chunks_allocated;
  long chunks_freed;
  long free_length;
  } hm_stats;
*/

typedef struct node_t {
    size_t size; 
    struct node_t *next;
} node;

const size_t PAGE_SIZE = 4096;
static hm_stats stats; // This initializes the stats to 0.

//initialize free list
node * head = NULL;

void free_list_add(void * item) {
    void* item_start = item - sizeof(size_t);
    size_t* item_size_p = item_start;
    size_t item_size = *item_size_p;
    node * cur_node = head;
    if(head == NULL) {
        node * insert = item_start;
        insert->size = item_size;
        insert->next = NULL;
        head = insert;
        return;
    }
    node * last_node = NULL;
    while(cur_node != NULL && (void *)cur_node < item_start) {
        last_node = cur_node;
        cur_node = cur_node->next;            
    }
    if(cur_node == head) {
        node * insert = item_start;
        insert->next = cur_node;
        insert->size = item_size;
        head = insert;
    }
    else {
        node * insert = item_start;
        insert->next = cur_node;
        insert->size = item_size;
        last_node->next = insert;
    }
}

void * free_list_check(size_t size) {
    node * cur_node = head;
    node * last_node = NULL;
    void * retval = NULL;
    while(cur_node != NULL) {
        if(cur_node->size >= size) {
            retval = cur_node;
            size_t * ret_size = retval;
            retval += sizeof(size_t);
            
            //if the leftover is too little, just give the whole chunk and remove from list
            if(cur_node->size - size < sizeof(node)) {
                if(cur_node == head) {
                    head = cur_node->next;
                }
                else {
                    last_node->next = cur_node->next;
                }
            }
            else {
                if(cur_node == head) {
                    size_t prev_size = cur_node->size;
                    node * old_next = cur_node->next;
                    void * new_loc = cur_node;
                    new_loc += size;
                    cur_node = new_loc;
                    cur_node->size = prev_size - size;
                    cur_node->next = old_next;
                    head = cur_node;
                }
                else {
                    size_t prev_size = cur_node->size;
                    node * old_next = cur_node->next;
                    void * new_loc = cur_node;
                    new_loc += size;
                    cur_node = new_loc;
                    cur_node->size = prev_size - size;
                    cur_node->next = old_next;
                    last_node->next = cur_node;
                }
                
                //we must set a new size, since we are only returning part of the block
                *ret_size = size;
            }
            return retval;
        }
        last_node = cur_node;
        cur_node = cur_node->next;
    }
    return NULL;
}

void free_list_coalesce() {
    node * cur_node = head;
    if(head == NULL || head->next == NULL) {
        return;
    }
    node * next_node = cur_node->next;
    while(next_node != NULL) {
        void * node_p = cur_node;
        if(node_p + cur_node->size == next_node) {
            cur_node->size += next_node->size;
            cur_node->next = next_node->next;
            next_node = cur_node->next;
        }
        else {
            cur_node = next_node;
            next_node = cur_node->next;
        }
    }
}

long
free_list_length()
{
    //Calculate the length of the free list.
    
    node * cur_node = head;
    long length = 0;
    while(cur_node != NULL) {
        length++;
        cur_node = cur_node->next;
    }
    return length;
}

hm_stats*
hgetstats()
{
    stats.free_length = free_list_length();
    return &stats;
}

void
hprintstats()
{
    stats.free_length = free_list_length();
    fprintf(stderr, "\n== husky malloc stats ==\n");
    fprintf(stderr, "Mapped:   %ld\n", stats.pages_mapped);
    fprintf(stderr, "Unmapped: %ld\n", stats.pages_unmapped);
    fprintf(stderr, "Allocs:   %ld\n", stats.chunks_allocated);
    fprintf(stderr, "Frees:    %ld\n", stats.chunks_freed);
    fprintf(stderr, "Freelen:  %ld\n", stats.free_length);
}

static
size_t
div_up(size_t xx, size_t yy)
{
    // This is useful to calculate # of pages
    // for large allocations.
    size_t zz = xx / yy;

    if (zz * yy == xx) {
        return zz;
    }
    else {
        return zz + 1;
    }
}

void*
hmalloc(size_t size)
{
    stats.chunks_allocated += 1;
    size += sizeof(size_t);
    if(size >= PAGE_SIZE - sizeof(node)) {
        size_t pages = div_up(size, PAGE_SIZE);
        void * block = mmap(NULL, pages * PAGE_SIZE, PROT_READ|PROT_WRITE, MAP_ANON|MAP_PRIVATE, -1, 0);
        stats.pages_mapped += pages;
        size_t * size_header = block;
        *size_header = pages * PAGE_SIZE;
        return block + sizeof(size_t);
    }
    else {
        void * slot = free_list_check(size);

        if(slot == NULL) {
            void * block = mmap(NULL, size, PROT_READ|PROT_WRITE, MAP_ANON|MAP_PRIVATE, -1, 0);
            stats.pages_mapped += 1;
            size_t * ret_size = block;
            *ret_size = size;
            void* ret_val = block;
            //give extra page memory back to the free list
            block += size;
            size_t* to_add_size = block;
            *to_add_size = PAGE_SIZE - size;
            free_list_add(block + sizeof(size_t));
            return ret_val + sizeof(size_t);        
        }
        else {
            return slot;
        }
    } 
}

void
hfree(void* item)
{
    stats.chunks_freed += 1;
    
    size_t * size = item - sizeof(size_t);
    if(*size >= PAGE_SIZE) {
        size_t pages = div_up(*size, PAGE_SIZE);
        stats.pages_unmapped += pages;
        munmap(size, pages * PAGE_SIZE);
    }
    else {
        free_list_add(item);
    }

    free_list_coalesce();
}

